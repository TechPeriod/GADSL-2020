package com.example.gadsl.models


data class Record(
    var hours: Int,
    var score: Int,
    var name: String,
    var country: String,
    var badgeUrl: String
)